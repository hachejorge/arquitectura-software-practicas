/* Implementación de la clase especifica CryptoCurrencyContrete
 * Autores: Jorge Hernández y Laura Hernández
 */

package CryptoCurrencies;

public class CryptoCurrencyConcrete extends CryptoCurrency {

    // Constructor de la moneda con nombre y precio
    public CryptoCurrencyConcrete(String _name, double _price){
        name = _name;
        price = _price;
    }

}
